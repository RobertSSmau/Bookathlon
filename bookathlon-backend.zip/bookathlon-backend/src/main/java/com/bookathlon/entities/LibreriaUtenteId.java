package com.bookathlon.entities;


//per gestire chiave composta, mi serve a JPA per sapere come identificare una riga univoca nella tabella libreria_utente


public class LibreriaUtenteId {

}
