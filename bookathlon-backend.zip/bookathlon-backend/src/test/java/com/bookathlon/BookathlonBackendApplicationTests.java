package com.bookathlon;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookathlonBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
